import { useState, useEffect, useRef } from 'react'
import { useAuthStore } from '../store/authStore'
import PrologueModal from '../components/PrologueModal'
import { Capacitor } from '@capacitor/core'
import { SocialLogin } from '@capgo/capacitor-social-login'

const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID

/* ── SVG Icon Components ─────────────────────────────────── */
function IconLightning({ size = 58 }) {
  return (
    <svg
      className="auth-bolt-icon"
      width={size} height={size}
      viewBox="0 0 58 58"
      fill="none"
      style={{ overflow: 'visible' }}
    >
      <defs>
        <linearGradient id="bolt-main-grad" x1="20" y1="3" x2="36" y2="55" gradientUnits="userSpaceOnUse">
          <stop offset="0%"   stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="20%"  stopColor="#ffe888" />
          <stop offset="55%"  stopColor="#ffaa20" />
          <stop offset="100%" stopColor="#ff5500" />
        </linearGradient>
        <linearGradient id="bolt-core-grad" x1="26" y1="6" x2="32" y2="50" gradientUnits="userSpaceOnUse">
          <stop offset="0%"   stopColor="#ffffff" />
          <stop offset="60%"  stopColor="#fff8cc" />
          <stop offset="100%" stopColor="#ffdd60" />
        </linearGradient>
        <filter id="bolt-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="2.5" result="b" />
          <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
        <filter id="spark-glow" x="-100%" y="-100%" width="300%" height="300%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="1.8" result="b" />
          <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>

      {/* Outer rotating dashed arc ring */}
      <g className="bolt-arc-ring">
        <circle cx="29" cy="29" r="25" stroke="rgba(255,170,30,0.3)" strokeWidth="1" strokeDasharray="5 9" fill="none" />
      </g>
      {/* Inner counter-rotating ring */}
      <g className="bolt-arc-ring-2">
        <circle cx="29" cy="29" r="21" stroke="rgba(255,210,70,0.2)" strokeWidth="0.8" strokeDasharray="2 11" fill="none" />
      </g>

      {/* Pulsing ambient halo */}
      <ellipse className="bolt-halo" cx="29" cy="30" rx="13" ry="15"
        fill="rgba(255,130,0,0.13)" filter="url(#spark-glow)" />

      {/* Main bolt body — RF-style angular/wide */}
      <polygon
        className="bolt-body"
        points="33,3 15,28 25,28 18,55 45,26 31,26"
        fill="url(#bolt-main-grad)"
        filter="url(#bolt-glow)"
      />
      {/* Inner bright core strip */}
      <polygon
        className="bolt-core"
        points="31,8 19,27 27,27 21,49 40,27 30,27"
        fill="url(#bolt-core-grad)"
        opacity="0.55"
      />
      {/* Highlight edge */}
      <polyline
        className="bolt-edge"
        points="33,3 31,26 45,26"
        stroke="rgba(255,255,200,0.55)"
        strokeWidth="1"
        fill="none"
        strokeLinejoin="round"
      />

      {/* Arc flash lines — electric sparks radiating from center */}
      <line className="bolt-arc-line al1" x1="29" y1="29" x2="6"  y2="14" stroke="rgba(255,220,80,0.8)"  strokeWidth="0.9" />
      <line className="bolt-arc-line al2" x1="29" y1="29" x2="52" y2="12" stroke="rgba(255,200,50,0.7)"  strokeWidth="0.7" />
      <line className="bolt-arc-line al3" x1="29" y1="29" x2="4"  y2="42" stroke="rgba(255,180,40,0.65)" strokeWidth="0.8" />
      <line className="bolt-arc-line al4" x1="29" y1="29" x2="53" y2="46" stroke="rgba(255,200,60,0.6)"  strokeWidth="0.6" />
      <line className="bolt-arc-line al5" x1="29" y1="29" x2="29" y2="2"  stroke="rgba(255,250,150,0.5)" strokeWidth="0.6" />

      {/* Spark particle dots */}
      <circle className="bolt-spark bs1" cx="11" cy="17" r="1.4" fill="#ffee80" filter="url(#spark-glow)" />
      <circle className="bolt-spark bs2" cx="47" cy="19" r="1.0" fill="#ffffff"  filter="url(#spark-glow)" />
      <circle className="bolt-spark bs3" cx="8"  cy="36" r="1.2" fill="#ffcc40" filter="url(#spark-glow)" />
      <circle className="bolt-spark bs4" cx="49" cy="39" r="1.4" fill="#ffee80" filter="url(#spark-glow)" />
      <circle className="bolt-spark bs5" cx="22" cy="6"  r="0.9" fill="#ffffff"  filter="url(#spark-glow)" />
      <circle className="bolt-spark bs6" cx="36" cy="52" r="1.1" fill="#ff9930" filter="url(#spark-glow)" />
      <circle className="bolt-spark bs7" cx="51" cy="29" r="0.8" fill="#ffe070" filter="url(#spark-glow)" />
      <circle className="bolt-spark bs8" cx="7"  cy="27" r="0.9" fill="#ffdd60" filter="url(#spark-glow)" />
    </svg>
  )
}

function IconBook({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
      <line x1="8" y1="7" x2="16" y2="7" />
      <line x1="8" y1="11" x2="14" y2="11" />
    </svg>
  )
}

function IconDiamond({ size = 10 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 10 10" fill="none">
      <polygon points="5,1 9,5 5,9 1,5" stroke="currentColor" strokeWidth="1" fill="rgba(80,130,200,0.3)" />
    </svg>
  )
}

function IconArrow({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <line x1="5" y1="12" x2="19" y2="12" />
      <polyline points="13 6 19 12 13 18" />
    </svg>
  )
}

function IconRocket({ size = 16 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2" />
      <path d="M12 2L8 8H4l3 4-1 5 5-3 5 3-1-5 3-4h-4z" />
    </svg>
  )
}

function IconWarning({ size = 14 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
      <line x1="12" y1="9" x2="12" y2="13" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
  )
}

/* ── Star particles — tri-faction colors ────────────────── */
// cyan = Bionex, orange = Arctron, purple = Celestra, white = neutral
const STARS = [
  { top: '4%',  left: '7%',  size: 2,   d: '2.8s', delay: '0s',   color: '#00e5ff' },
  { top: '8%',  left: '82%', size: 1.5, d: '3.4s', delay: '0.7s', color: '#00e5ff' },
  { top: '14%', left: '55%', size: 2.5, d: '4.1s', delay: '1.4s', color: '#c8dff8' },
  { top: '20%', left: '90%', size: 3,   d: '2.6s', delay: '0.3s', color: '#d000ff' },
  { top: '28%', left: '3%',  size: 1.5, d: '3.8s', delay: '2.0s', color: '#ff6400' },
  { top: '38%', left: '68%', size: 2,   d: '3.1s', delay: '1.1s', color: '#c8dff8' },
  { top: '50%', left: '92%', size: 2.5, d: '4.5s', delay: '0.5s', color: '#d000ff' },
  { top: '58%', left: '2%',  size: 2,   d: '2.9s', delay: '1.8s', color: '#ff6400' },
  { top: '65%', left: '78%', size: 1.5, d: '3.6s', delay: '0.9s', color: '#c8dff8' },
  { top: '72%', left: '12%', size: 3,   d: '4.2s', delay: '2.4s', color: '#ff6400' },
  { top: '82%', left: '88%', size: 2,   d: '3.3s', delay: '0.2s', color: '#d000ff' },
  { top: '88%', left: '42%', size: 1.5, d: '2.7s', delay: '1.6s', color: '#00e5ff' },
  { top: '94%', left: '65%', size: 2,   d: '3.9s', delay: '0.8s', color: '#c8dff8' },
  { top: '96%', left: '18%', size: 1.5, d: '2.5s', delay: '1.3s', color: '#ff6400' },
]

/* ── Component ───────────────────────────────────────────── */
export default function Auth() {
  const [mode, setMode] = useState('login')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPrologue, setShowPrologue] = useState(false)
  const googleBtnRef = useRef(null)

  const signIn          = useAuthStore((s) => s.signIn)
  const signUp          = useAuthStore((s) => s.signUp)
  const signInWithGoogle = useAuthStore((s) => s.signInWithGoogle)
  const error           = useAuthStore((s) => s.error)
  const loading         = useAuthStore((s) => s.loading)
  const clearError      = useAuthStore((s) => s.clearError)

  useEffect(() => {
    if (Capacitor.isNativePlatform()) {
      SocialLogin.initialize({ google: { webClientId: GOOGLE_CLIENT_ID } })
        .catch(err => console.error('SocialLogin init fail:', err))
      return
    }
    const initGoogle = () => {
      if (!window.google || !GOOGLE_CLIENT_ID) return
      window.google.accounts.id.initialize({
        client_id: GOOGLE_CLIENT_ID,
        callback: async (response) => { clearError(); await signInWithGoogle(response.credential) },
      })
      if (googleBtnRef.current) {
        window.google.accounts.id.renderButton(googleBtnRef.current, {
          theme: 'filled_black', size: 'large',
          width: googleBtnRef.current.offsetWidth || 300,
          text: 'continue_with', shape: 'rectangular',
        })
      }
    }
    if (window.google) { initGoogle() }
    else {
      const iv = setInterval(() => { if (window.google) { clearInterval(iv); initGoogle() } }, 200)
      return () => clearInterval(iv)
    }
  }, [])

  const handleNativeGoogle = async () => {
    try {
      clearError()
      const res = await SocialLogin.login({ provider: 'google' })
      const idToken = res.result?.idToken || res.authentication?.idToken
      if (idToken) await signInWithGoogle(idToken)
      else alert('Gagal mengambil Google Token.')
    } catch (err) {
      console.error('Native Google login error:', err)
      alert('Native Google login error: ' + (err.message || JSON.stringify(err)))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    clearError()
    if (mode === 'login') await signIn(username.trim(), password)
    else await signUp(username.trim(), password)
  }

  const submitLabel = loading
    ? '— LOADING —'
    : mode === 'login'
      ? 'ENTER SYSTEM'
      : 'CREATE PILOT'

  return (
    <div className="auth-root">

      {/* Star field */}
      <div className="auth-stars" aria-hidden="true">
        {STARS.map((s, i) => (
          <span
            key={i}
            className="auth-star"
            style={{
              top: s.top, left: s.left,
              width: s.size, height: s.size,
              '--d': s.d, '--delay': s.delay,
              background: s.color,
              boxShadow: `0 0 4px 1px ${s.color}88`,
            }}
          />
        ))}
      </div>

      {/* HUD terminal card */}
      <div className="auth-card">

        {/* HUD Frame decorations */}
        <span className="auth-corner tl" aria-hidden="true" />
        <span className="auth-corner tr" aria-hidden="true" />
        <span className="auth-corner bl" aria-hidden="true" />
        <span className="auth-corner br" aria-hidden="true" />
        {/* Top center notch */}
        <span className="auth-hud-notch-top" aria-hidden="true" />
        {/* Side mid-brackets */}
        <span className="auth-hud-side-l" aria-hidden="true" />
        <span className="auth-hud-side-r" aria-hidden="true" />
        {/* Bottom center tick */}
        <span className="auth-hud-notch-bot" aria-hidden="true" />

        {/* Logo */}
        <div className="auth-logo">
          <div className="auth-logo-icon">
            <IconLightning size={52} />
          </div>
          <span className="auth-logo-text">FOCUS RPG</span>
          <div className="auth-logo-sep">
            <span className="auth-logo-sep-line" />
            <IconDiamond size={8} />
            <span className="auth-logo-sep-line" />
          </div>
          <span className="auth-logo-sub">Idle Battle System</span>
        </div>

        {/* Lore button */}
        <button type="button" className="auth-lore-btn" onClick={() => setShowPrologue(true)}>
          <IconBook size={14} />
          Sejarah Dunia — Lore Prologue
        </button>

        {/* Google sign-in */}
        {GOOGLE_CLIENT_ID && (
          <div className="auth-google-wrap">
            {Capacitor.isNativePlatform() ? (
              <button type="button" className="auth-google-btn-native" onClick={handleNativeGoogle} disabled={loading}>
                <svg className="auth-google-icon" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.85c.87-2.6 3.3-4.53 6.16-4.53z" />
                </svg>
                Continue with Google
              </button>
            ) : (
              <div ref={googleBtnRef} className="auth-google-placeholder" />
            )}
            <div className="auth-divider">
              <span className="auth-divider-line" />
              <span className="auth-divider-diamond"><IconDiamond size={9} /></span>
              <span style={{ fontSize: 10, letterSpacing: 3 }}>atau</span>
              <span className="auth-divider-diamond"><IconDiamond size={9} /></span>
              <span className="auth-divider-line" />
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="auth-tabs">
          <button
            className={`auth-tab${mode === 'login' ? ' active' : ''}`}
            onClick={() => { setMode('login'); clearError() }}
          >
            Login
          </button>
          <button
            className={`auth-tab${mode === 'register' ? ' active' : ''}`}
            onClick={() => { setMode('register'); clearError() }}
          >
            Register
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="auth-field">
            <label className="auth-label">
              <span className="auth-label-bracket">[</span>
              Username
              <span className="auth-label-bracket">]</span>
            </label>
            <input
              className="auth-input"
              type="text"
              placeholder="pilot123"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              autoCapitalize="none"
              autoCorrect="off"
              required
            />
          </div>

          <div className="auth-field">
            <label className="auth-label">
              <span className="auth-label-bracket">[</span>
              Password
              <span className="auth-label-bracket">]</span>
            </label>
            <input
              className="auth-input"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
            />
          </div>

          {error && (
            <div className="auth-error">
              <span className="auth-error-icon"><IconWarning size={14} /></span>
              {error}
            </div>
          )}

          <button className="auth-submit" type="submit" disabled={loading}>
            {loading ? submitLabel : (
              <>
                {mode === 'login' ? <IconArrow size={16} /> : <IconRocket size={16} />}
                {submitLabel}
              </>
            )}
          </button>
        </form>

        {/* Hint */}
        <div className="auth-hint">
          {mode === 'login'
            ? 'Belum punya akun — pilih Register'
            : 'Progress tersimpan di server — sync semua device'}
        </div>

      </div>

      {showPrologue && <PrologueModal onClose={() => setShowPrologue(false)} />}
    </div>
  )
}
