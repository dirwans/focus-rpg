# Handoff: Knight Attack Animation + Sci-Fi Cyborg 3D Object

## Overview
Two independent design deliverables:
1. **Knight Attack** — a looping 2D game-sprite style character animation (idle → sword strike → jump slash) built from the user's own armor-part PNGs, with a camera, HUD, and tweakable controls.
2. **Cyborg 3D Object** — a realistic sci-fi humanoid robot modeled in three.js, viewable from any angle and exportable as OBJ+MTL or GLB.

## About the Design Files
The files in this bundle are **design references built in HTML/JS (React via Babel)** — working prototypes showing the intended look, motion, and interaction, not production application code. The task is to **recreate this behavior in the target codebase's real environment** (game engine, React app, native app, etc.) using its established rendering/animation patterns — or choose the most suitable approach if no environment exists yet. Do not simply embed these HTML files into a production app.

## Fidelity
**High-fidelity.** Colors, proportions, timing, and easing curves below are final choices, not placeholders — reproduce them as closely as the target environment allows.

---

## 1) Knight Attack Animation

### Purpose
A looping character "idle / attack" cycle for a game or promo piece: a mecha-armored knight breathes at idle, then performs two attack moves (a sword strike, then a jump slash) before returning to idle and looping.

### Files
- `knight_attack/KnightAttack.dc.html` — entry document; declares the scene list and tweak defaults as inline JSON (see below), and mounts the app.
- `knight_attack/knight-attack.jsx` — all animation logic and rig/layout (React function components, inline styles).
- `knight_attack/animations-v2.jsx` — generic timeline/scene-sequencing engine (Stage, SceneStage, Easing, interpolate, useScene, etc.). Reusable engine code, not specific to this design.
- `knight_attack/tweaks-panel.jsx` — generic tweak-controls UI shell. Reusable, not specific to this design.
- `knight_attack/uploads/*.png` — the 7 source art assets (helmet, left arm, right arm, leg/boot ×2 identical, shield, sword). **No torso/chest art was supplied** — the torso is currently a procedurally drawn, gradient-shaded placeholder; supply real torso art and swap it in.

### Canvas & Coordinate System
1280×720 canvas. A "world" layer (background + character) is scaled/translated for camera zoom/shake; a fixed dungeon background (floor, wall, two torches) sits behind the character. HUD health bar top-left ("SIR ROLAND", monospace pixel font "Press Start 2P", gold-bordered red bar).

### The Character Rig
The knight is a paper-doll rig: a container positioned at `left: 470, top: FLOOR_Y - 420` (FLOOR_Y = 560), height 420px. Each limb is an `<img>` wrapped in a zero-size pivot `<div>` positioned at the joint location, rotated by an animated angle around `transformOrigin: '0 0'`, with the image itself offset by a negative `(left, top)` so the art's own attachment point (shoulder, hip, hand, neck) lands exactly on the pivot. This lets a single rotation value swing an entire limb image believably without a bone/skin system.

Key pivots (local px within the rig container):
- Neck/head: `(85, 114)` — helmet image offset `(-32.25, -63.6)` at display size 64.5×74.
- Shoulders: right `(106, 118)`, left `(64, 118)` — arm images at display size ~97.5×150 (right) / 71.1×150 (left), offset so each image's own shoulder corner sits on the pivot.
- Hips: right `(108, 195)`, left `(64, 195)` — leg/boot image (one asset, mirrored via `scaleX(-1)` with `transformOrigin: '0 0'` for the other side) at display size 230×230, offset `(-115, -9.2)`.
- Sword: nested inside the right-arm pivot's local space at offset `(58.5, 130.5)` from the shoulder pivot (i.e. the estimated hand position), with an extra fixed `rotate(-18deg)` to seat the grip naturally, image size 185.9×200.
- Shield: nested inside the left-arm pivot, offset `(-62, 40)`, image size 74.7×120.
- Torso (placeholder): two stacked rounded rects (chest + abdomen plates) at `left: HEAD_X-30, top: NECK_Y+8`, each with a CSS `linear-gradient` (lighten/darken the current armor-tone color ±14–22%) plus inset box-shadows to fake a painted-metal bevel, and a small gold diamond emblem.

### Animation Timeline (scenes, authored in `window.OM_SCENES` as JSON — do not hand-edit the object shape, only durations were meant to be user-tunable via the host's timeline UI)
```
[{"name":"Ready","dur":1.6},{"name":"Strike","dur":3.4},{"name":"JumpSlash","dur":3.0}]
```
Total loop length: 8s. Plays on loop (`window.OM_PLAYBACK = {"mode":"loop"}`).

**Scene "Ready" (1.6s, wide shot, camera scale 1.0):** idle breathing sway. `sway = sin(progress·4π)·3` (exactly 2 full cycles, so it is 0 at both scene edges — required so the loop cut is seamless). Feeds `shoulderAngle = -8 + sway·0.3`, `torsoLean = sway·0.4`.

**Scene "Strike" (3.4s, camera zoomed to 1.3–1.42, closer shot):** a single continuous swing built from one 7-keyframe interpolation across normalized progress 0–1 (keyframe times `[0, 0.10, 0.32, 0.44, 0.50, 0.75, 1.0]`):
- `shoulderAngle`: -8 → -8 (hold) → **-150** (wind-up, `easeInCubic`) → **46** (strike, `easeOutBack` for a whip-crack overshoot) → 46 (hold) → -8 (recover, `easeOutCubic`) → -8 (settle).
- `torsoLean`: 0 → 0 → -6 (lean back on wind-up) → 10 (lean into the strike) → 10 → 0 → 0.
- `kneeShift` (front-leg lunge, px translateX): 0 → 0 → -4 → 14 → 14 → 0 → 0.
- `camScale`: 1.3 constant, punches to 1.42 in a narrow window around progress 0.44–0.60 (impact zoom-in).
- Screen shake: a triangular envelope peaking at progress 0.47 (`[0,0.44,0.47,0.50,1] → [0,0,1,0,0]`) drives `shakeX/Y = envelope · amplitude · sin/cos(progress·k)`; amplitude is a tweak (`cameraShake` toggle, 6px on / 0 off).
- Impact spark: a radial-gradient green flash (`rgba(210,255,235,.95)→rgba(120,255,200,.65)→transparent`) fades in/out around the same 0.47 peak, plus a diagonal "speed lines" repeating-gradient overlay opaque only during the fast swing window (progress 0.30–0.48).

**Scene "JumpSlash" (3.0s, camera ~1.12 with a small punch to 1.22 at the slash):** crouch → leap → overhead slash at the apex → fall → landing squash, all as one 9-keyframe interpolation (times `[0,0.08,0.22,0.46,0.50,0.66,0.84,0.90,1.0]`):
- `shoulderAngle`: -8 → -8 → **-165** (big wind-up while airborne-bound) → -165 (hold through the rise) → **75** (downward slash) → 55 → -8 → -8 → -8.
- `jumpY` (px translateY on the whole rig, negative = up): 0 → 0 → 12 (crouch dips down) → **-110** (apex, `linear` hold across the rise segment) → -110 → -60 (falling) → 4 (slight overshoot below ground = impact) → -3 (rebound) → 0.
- `squashY` (scaleY on the whole rig, origin bottom-center): 1 → 1 → 0.85 (crouch squash) → 1.07 (mid-air stretch) → 1.07 → 0.97 → **0.82** (landing squash) → 1.04 (rebound overshoot) → 1.
- Ground shadow fades/shrinks with `|jumpY|` (airborne = smaller, fainter shadow); a landing dust puff (two soft blurred ellipses) fades in/out in a narrow window at progress 0.80–0.95.
- Camera follows partially: `shakeY += jumpY · 0.22` (subtle vertical parallax as the character leaps), plus the same impact-shake technique as Strike, triggered twice (slash apex ~0.50, landing ~0.84).

**Critical constraint carried through all three scenes:** every animated channel is authored so its value at progress 0 and progress 1 is IDENTICAL to neutral idle (shoulderAngle -8, torsoLean 0, jumpY 0, squashY 1, all effects opacity 0). This is what makes the hard cuts between scenes, and the final loop-back to "Ready", invisible/seamless. If you retime or restructure this in the target engine, preserve that invariant.

### Tweakable Controls (already wired to a tweaks panel; current saved values)
- `armorTone` (color, currently `#8f7aa8`) — recolors the two procedural torso plates via the `shade()` helper (lighten/darken the base hex by a %). Options offered: `#6e6280, #8f7aa8, #4a4550, #8a6a3f`.
- `hudVisible` (boolean, currently `true`) — shows/hides the health-bar HUD.
- `cameraShake` (boolean, currently `false`) — enables/disables the impact screen-shake on Strike and JumpSlash.
- `motionEditor` (boolean, currently `true`) — internal to the prototyping host only; not part of the design, ignore in the handoff.

### Assets
All 7 PNGs in `knight_attack/uploads/` are user-supplied game-art (mecha/armor style, purple-silver metal with gold trim, glowing emerald sword, dark shield with a red gem). `right_leg_boot_battle.png` is used for BOTH legs (mirrored). No separate torso art exists yet.

---

## 2) Cyborg 3D Object

### Purpose
A realistic sci-fi humanoid cyborg, modeled for inspection/download (product-viz or game-asset reference), not for the game character above — separate character concept.

### Files
- `cyborg_3d/Cyborg.html` — full page: import map (three.js r0.184.0 pinned, from the "3D object" workflow), the `<three-d-stage>` viewer web component, and a module script that builds the model.
- `cyborg_3d/three-d-stage.js` — reusable viewer shell (studio lighting, ground shadow, orbit controls, auto-framed camera, OBJ+MTL / GLB export toolbar). Not specific to this model.

### Model
A `THREE.Group` named `cyborg`, built entirely from primitives (box/cylinder/sphere geometries), real-world meters, y-up, centered on the origin, feet at y=0, standing ~1.9m tall:
- **Torso column** (not mirrored): pelvis (box), abdomen (box, darker joint material), chest (box) with an emissive cyan disc "core light", neck (cylinder).
- **Head**: box with a glass-look visor band + an emissive cyan visor line, a thin antenna with an emissive tip.
- **Backpack**: box behind the chest with two cylindrical exhaust housings, each with a small emissive glow disc.
- **Arms (mirrored L/R via a shared `buildArm(side)` function)**: shoulder ball joint → upper-arm cylinder → elbow ball joint (nested group, fixed bend) → forearm cylinder + vent box → hand group (palm box + 3 finger boxes + 1 thumb box).
- **Legs (mirrored L/R via `buildLeg(side)`)**: hip ball joint → thigh cylinder → knee ball joint (nested group) → shin cylinder + shin-guard box → foot group (angled foot block).

### Materials (5, shared across parts — names are the exported OBJ/GLB material names)
- `gunmetal` — `#383c42`, metalness 0.35, roughness 0.45 (head, forearms, shins, hands).
- `plating_steel` — `#6f7680`, metalness 0.3, roughness 0.35 (chest, upper arms, thighs, vents, shin guards).
- `joint_dark` — `#16171a`, metalness 0.25, roughness 0.6 (all ball joints, abdomen, fingers).
- `visor_glass` — `#0c1116`, metalness 0.1, roughness 0.15 (head visor).
- `core_glow` — base `#6be8ef`, emissive `#4fd6e0`, emissiveIntensity 2 (chest core disc, visor line, antenna tip, exhaust glows).

Every mesh is individually named (e.g. `shoulderJoint_R`, `forearm_L`, `footBlock_R`) — these names become the `o`/`usemtl` entries in the OBJ export and the node names in the GLB, so they should carry through to whatever the target pipeline imports.

### Export
The stage's toolbar already exports **OBJ + MTL** and **GLB** directly from the browser — hand those files to the target 3D/engine pipeline (Blender, Unity, Unreal, etc.) rather than re-modeling from scratch, unless the target needs a different format (FBX/USDZ/STEP are not produced by this tool).

---

## Design Tokens (Knight Attack)
- **Colors**: dungeon wall `#211d19`, floor `#3b332b`, torch glow `#ffb454`, gold trim `#c9a24b`, HUD panel `rgba(10,10,10,0.55)`, HUD bar red `#b8332f`, sword glow greens `rgba(210,255,235,.95)/rgba(120,255,200,.65)`, armor tone tweak default `#8f7aa8`.
- **Typography**: HUD label — `'Press Start 2P', monospace`, 10px, letter-spacing 1px (Google Fonts).
- **Canvas**: 1280×720 fixed.

## Next Steps / Open Items
1. Supply real torso/chest art for the knight (currently a procedural placeholder) and swap the two gradient rects for the image, recalculating its attach offset the same way the other limbs were done.
2. Confirm which engine/framework the knight animation should target (game engine sprite/animator, CSS/React web experience, etc.) — the timing curves and keyframes above are engine-agnostic and should transfer directly.
3. If real bone rigging is wanted instead of image-swing-on-pivot, treat the pivot points documented above as the joint locations to rig.
