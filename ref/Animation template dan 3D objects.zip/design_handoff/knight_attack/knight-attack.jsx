// knight-attack.jsx — 2D game-sprite style knight attack animation.
// Loaded after animations-v2.jsx and tweaks-panel.jsx (globals: SceneStage,
// useScene, Easing, interpolate, clamp, useTweaks, TweaksPanel, TweakSection,
// TweakToggle, TweakColor).

var W = 1280, H = 720;
function shade(hex, pct) {
  var n = parseInt(hex.replace('#', ''), 16);
  var r = Math.min(255, Math.max(0, ((n >> 16) & 255) + Math.round(255 * pct)));
  var g = Math.min(255, Math.max(0, ((n >> 8) & 255) + Math.round(255 * pct)));
  var b = Math.min(255, Math.max(0, (n & 255) + Math.round(255 * pct)));
  return 'rgb(' + r + ',' + g + ',' + b + ')';
}
var FLOOR_Y = 560;
var ARMOR_DARK = '#343a44';
var STEEL_LIGHT = '#d8dde3';
var GOLD = '#c9a24b';
var PLUME = '#8b3b3b';

function GameBackground(props) {
  var hudVisible = props.hudVisible;
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div style={{ position: 'absolute', top: 0, left: 0, width: W, height: FLOOR_Y, background: '#211d19' }} />
      <div style={{
        position: 'absolute', top: 0, left: 0, width: W, height: FLOOR_Y,
        background: 'repeating-linear-gradient(90deg, rgba(0,0,0,0.12) 0 2px, transparent 2px 96px)',
      }} />
      <div style={{ position: 'absolute', top: FLOOR_Y, left: 0, width: W, height: H - FLOOR_Y, background: '#3b332b' }} />
      <div style={{
        position: 'absolute', top: FLOOR_Y, left: 0, width: W, height: H - FLOOR_Y,
        background: 'repeating-linear-gradient(90deg, rgba(0,0,0,0.18) 0 6px, transparent 6px 130px)',
      }} />
      {[150, 1130].map(function (x, i) {
        return (
          <div key={i} style={{ position: 'absolute', left: x - 6, top: 210, width: 12, height: 46, background: '#171412', borderRadius: 2 }}>
            <div style={{
              position: 'absolute', left: -7, top: -22, width: 26, height: 26, borderRadius: '50%',
              background: '#ffb454', boxShadow: '0 0 24px 10px rgba(255,150,60,0.55), 0 0 60px 26px rgba(255,110,30,0.25)',
            }} />
          </div>
        );
      })}
      {hudVisible && (
        <div style={{
          position: 'absolute', left: 24, top: 22, padding: '10px 14px', borderRadius: 6,
          background: 'rgba(10,10,10,0.55)', border: '1px solid rgba(255,255,255,0.1)',
          display: 'flex', flexDirection: 'column', gap: 6, width: 210,
        }}>
          <div style={{ fontFamily: "'Press Start 2P', monospace", fontSize: 10, color: '#f2ede2', letterSpacing: 1 }}>SIR ROLAND</div>
          <div style={{ height: 12, borderRadius: 3, border: '2px solid ' + GOLD, background: '#2a1414', padding: 2 }}>
            <div style={{ height: '100%', width: '82%', borderRadius: 1, background: '#b8332f' }} />
          </div>
        </div>
      )}
    </div>
  );
}

function Knight(props) {
  var shoulderAngle = props.shoulderAngle, torsoLean = props.torsoLean, kneeShift = props.kneeShift;
  var armor = props.armor, sparkOpacity = props.sparkOpacity, sparkScale = props.sparkScale;
  var speedOpacity = props.speedOpacity, sway = props.sway || 0;
  var jumpY = props.jumpY || 0;
  var squashY = props.squashY != null ? props.squashY : 1;
  var dustOpacity = props.dustOpacity || 0, dustScale = props.dustScale != null ? props.dustScale : 1;
  var shadowFade = Math.max(0.12, 0.35 - Math.abs(jumpY) / 480);
  var shadowScale = 1 - Math.min(0.45, Math.abs(jumpY) / 240);
  var RIG_H = 420;
  var HEAD_X = 85, NECK_Y = 114, SHOULDER_Y = 118, R_SH_X = 106, L_SH_X = 64, HIP_Y = 195, R_HIP_X = 108, L_HIP_X = 64;
  return (
    <div style={{ position: 'absolute', left: 470, top: FLOOR_Y - RIG_H, width: 170, height: RIG_H, transform: 'translateY(' + jumpY + 'px) scaleY(' + squashY + ')', transformOrigin: '50% 100%' }}>
      <div style={{ position: 'absolute', left: -10, top: RIG_H - 8, width: 190, height: 18, borderRadius: '50%', background: 'rgba(0,0,0,' + shadowFade + ')', filter: 'blur(2px)', transform: 'scale(' + shadowScale + ')' }} />
      <div style={{ position: 'absolute', left: 30, top: RIG_H - 4, width: 60, height: 14, borderRadius: '50%', background: 'rgba(214,200,180,0.5)', opacity: dustOpacity, transform: 'scale(' + dustScale + ')', filter: 'blur(3px)' }} />
      <div style={{ position: 'absolute', left: 90, top: RIG_H - 6, width: 70, height: 16, borderRadius: '50%', background: 'rgba(214,200,180,0.4)', opacity: dustOpacity, transform: 'scale(' + dustScale + ')', filter: 'blur(4px)' }} />

      {/* back leg (mirrored copy of the same leg asset) */}
      <div style={{ position: 'absolute', left: L_HIP_X, top: HIP_Y, width: 0, height: 0, transform: 'scaleX(-1)', transformOrigin: '0 0', zIndex: 1 }}>
        <img src="uploads/right_leg_boot_battle.png" style={{ position: 'absolute', left: -115, top: -9.2, width: 230, height: 230 }} />
      </div>
      {/* front leg (lunges forward on strike) */}
      <div style={{ position: 'absolute', left: R_HIP_X, top: HIP_Y, width: 0, height: 0, zIndex: 2, transform: 'translateX(' + kneeShift + 'px)' }}>
        <img src="uploads/right_leg_boot_battle.png" style={{ position: 'absolute', left: -115, top: -9.2, width: 230, height: 230 }} />
      </div>

      {/* torso (procedural — no torso art supplied — shaded/segmented to match the painted armor plates) */}
      <div style={{
        position: 'absolute', left: HEAD_X - 30, top: NECK_Y + 8, width: 62, height: 100,
        transformOrigin: '50% 100%', transform: 'rotate(' + torsoLean + 'deg)', zIndex: 3,
      }}>
        <div style={{
          position: 'absolute', left: 0, top: 0, width: 62, height: 48, borderRadius: '10px 10px 4px 4px',
          background: 'linear-gradient(128deg, ' + shade(armor, 0.22) + ' 0%, ' + armor + ' 45%, ' + shade(armor, -0.22) + ' 100%)',
          boxShadow: 'inset -6px -4px 10px rgba(0,0,0,0.35), inset 3px 3px 6px rgba(255,255,255,0.18)',
          borderBottom: '2px solid ' + shade(armor, -0.35),
        }}>
          <div style={{ position: 'absolute', left: '50%', top: 15, width: 12, height: 12, marginLeft: -6, background: GOLD, transform: 'rotate(45deg)', boxShadow: '0 0 6px rgba(201,162,75,0.6)' }} />
        </div>
        <div style={{
          position: 'absolute', left: 4, top: 50, width: 54, height: 50, borderRadius: '4px 4px 10px 10px',
          background: 'linear-gradient(128deg, ' + shade(armor, 0.14) + ' 0%, ' + shade(armor, -0.06) + ' 45%, ' + shade(armor, -0.3) + ' 100%)',
          boxShadow: 'inset -6px -4px 10px rgba(0,0,0,0.38), inset 2px 2px 5px rgba(255,255,255,0.12)',
        }} />
      </div>

      {/* left arm + shield (rear, mostly static) */}
      <div style={{ position: 'absolute', left: L_SH_X, top: SHOULDER_Y, width: 0, height: 0, transform: 'rotate(' + (sway * 0.5 - 4) + 'deg)', transformOrigin: '0 0', zIndex: 6 }}>
        <img src="uploads/lv1_arc_war_battle_left_arm.png" style={{ position: 'absolute', left: -14.22, top: -9, width: 71.1, height: 150 }} />
        <img src="uploads/shield-battle.png" style={{ position: 'absolute', left: -62, top: 40, width: 74.7, height: 120 }} />
      </div>

      {/* helmet */}
      <div style={{ position: 'absolute', left: HEAD_X, top: NECK_Y, width: 0, height: 0, transform: 'rotate(' + (torsoLean * 0.6) + 'deg)', transformOrigin: '0 0', zIndex: 4 }}>
        <img src="uploads/lv1_arc_war_battle_helmet.png" style={{ position: 'absolute', left: -32.25, top: -63.6, width: 64.5, height: 74 }} />
      </div>

      {/* right arm + sword (front, swings on the shoulder pivot) */}
      <div style={{ position: 'absolute', left: R_SH_X, top: SHOULDER_Y, width: 0, height: 0, transform: 'rotate(' + shoulderAngle + 'deg)', transformOrigin: '0 0', zIndex: 5 }}>
        <img src="uploads/lv1_arc_war_battle_right_arm.png" style={{ position: 'absolute', left: -17.55, top: -9, width: 97.5, height: 150 }} />
        <div style={{ position: 'absolute', left: 58.5, top: 130.5, width: 0, height: 0, transform: 'rotate(-18deg)', transformOrigin: '0 0' }}>
          <img src="uploads/sword_battle.png" style={{ position: 'absolute', left: -9.3, top: -190, width: 185.9, height: 200 }} />
          <div style={{
            position: 'absolute', left: -40, top: -210, width: 70, height: 70, borderRadius: '50%', opacity: speedOpacity,
            background: 'repeating-linear-gradient(20deg, rgba(160,255,220,0.6) 0 3px, transparent 3px 14px)',
          }} />
          <div style={{
            position: 'absolute', left: -45, top: -215, width: 80, height: 80, borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(210,255,235,0.95) 0%, rgba(120,255,200,0.65) 40%, rgba(60,255,170,0) 70%)',
            opacity: sparkOpacity, transform: 'scale(' + sparkScale + ')',
          }} />
        </div>
      </div>
    </div>
  );
}

function World(props) {
  return (
    <div style={{ position: 'absolute', inset: 0, transform: 'scale(' + props.camScale + ') translate(' + props.shakeX + 'px,' + props.shakeY + 'px)', transformOrigin: '42% 74%' }}>
      <GameBackground hudVisible={props.hudVisible} />
      <Knight
        shoulderAngle={props.shoulderAngle} torsoLean={props.torsoLean} kneeShift={props.kneeShift}
        armor={props.armor} sparkOpacity={props.sparkOpacity} sparkScale={props.sparkScale}
        speedOpacity={props.speedOpacity} jumpY={props.jumpY} squashY={props.squashY}
        dustOpacity={props.dustOpacity} dustScale={props.dustScale}
      />
    </div>
  );
}

function ReadyScene(ctx) {
  var progress = ctx.progress;
  var sway = Math.sin(progress * Math.PI * 4) * 3;
  var t = ctx.tweaks;
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: '#0b0b0e', overflow: 'hidden' }}>
      <World
        camScale={1} shakeX={0} shakeY={0}
        shoulderAngle={-8 + sway * 0.3} torsoLean={sway * 0.4} kneeShift={0}
        armor={t.armorTone} sparkOpacity={0} sparkScale={0.6} speedOpacity={0}
        hudVisible={t.hudVisible}
      />
    </div>
  );
}

function StrikePose(progress) {
  var pts = [0, 0.10, 0.32, 0.44, 0.50, 0.75, 1.0];
  var eShoulder = [Easing.linear, Easing.easeInCubic, Easing.easeOutBack, Easing.linear, Easing.easeOutCubic, Easing.linear];
  var eTorso = eShoulder, eKnee = eShoulder;
  var shoulderAngle = interpolate(pts, [-8, -8, -150, 46, 46, -8, -8], eShoulder)(progress);
  var torsoLean = interpolate(pts, [0, 0, -6, 10, 10, 0, 0], eTorso)(progress);
  var kneeShift = interpolate(pts, [0, 0, -4, 14, 14, 0, 0], eKnee)(progress);
  var camScale = interpolate(
    [0, 0.44, 0.47, 0.50, 0.60, 1],
    [1.3, 1.3, 1.42, 1.42, 1.3, 1.3],
    [Easing.linear, Easing.easeOutQuad, Easing.linear, Easing.easeInQuad, Easing.linear]
  )(progress);
  var shakeEnv = interpolate([0, 0.44, 0.47, 0.50, 1], [0, 0, 1, 0, 0])(progress);
  var sparkOpacity = interpolate([0, 0.43, 0.47, 0.53, 1], [0, 0, 1, 0, 0])(progress);
  var sparkScale = interpolate([0, 0.43, 0.47, 0.60, 1], [0.4, 0.4, 1.15, 1, 0.4])(progress);
  var speedOpacity = interpolate([0, 0.30, 0.34, 0.44, 0.48, 1], [0, 0, 1, 1, 0, 0])(progress);
  return { shoulderAngle: shoulderAngle, torsoLean: torsoLean, kneeShift: kneeShift, camScale: camScale, shakeEnv: shakeEnv, sparkOpacity: sparkOpacity, sparkScale: sparkScale, speedOpacity: speedOpacity };
}

function StrikeScene(ctx) {
  var progress = ctx.progress;
  var t = ctx.tweaks;
  var p = StrikePose(progress);
  var shakeAmp = t.cameraShake ? 6 : 0;
  var shakeX = p.shakeEnv * shakeAmp * Math.sin(progress * 300);
  var shakeY = p.shakeEnv * shakeAmp * 0.6 * Math.cos(progress * 260);
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: '#0b0b0e', overflow: 'hidden' }}>
      <World
        camScale={p.camScale} shakeX={shakeX} shakeY={shakeY}
        shoulderAngle={p.shoulderAngle} torsoLean={p.torsoLean} kneeShift={p.kneeShift}
        armor={t.armorTone} sparkOpacity={p.sparkOpacity} sparkScale={p.sparkScale} speedOpacity={p.speedOpacity}
        hudVisible={t.hudVisible}
      />
    </div>
  );
}

function JumpSlashPose(progress) {
  var pts = [0, 0.08, 0.22, 0.46, 0.50, 0.66, 0.84, 0.90, 1.0];
  var e = [Easing.linear, Easing.easeInQuad, Easing.easeOutCubic, Easing.linear, Easing.easeOutBack, Easing.easeInCubic, Easing.easeOutQuad, Easing.easeInOutSine];
  var shoulderAngle = interpolate(pts, [-8, -8, -165, -165, 75, 55, -8, -8, -8], e)(progress);
  var torsoLean = interpolate(pts, [0, 0, -10, -6, 16, 8, 2, 0, 0], e)(progress);
  var jumpY = interpolate(pts, [0, 0, 12, -110, -110, -60, 4, -3, 0], e)(progress);
  var squashY = interpolate(pts, [1, 1, 0.85, 1.07, 1.07, 0.97, 0.82, 1.04, 1], e)(progress);
  var camScale = interpolate([0, 0.46, 0.50, 0.54, 0.84, 1], [1.12, 1.12, 1.22, 1.14, 1.12, 1.12], [Easing.linear, Easing.easeOutQuad, Easing.linear, Easing.easeInQuad, Easing.linear])(progress);
  var slashShakeEnv = interpolate([0, 0.47, 0.50, 0.55, 1], [0, 0, 1, 0, 0])(progress);
  var landShakeEnv = interpolate([0, 0.80, 0.84, 0.90, 1], [0, 0, 1, 0, 0])(progress);
  var sparkOpacity = interpolate([0, 0.47, 0.50, 0.56, 1], [0, 0, 1, 0, 0])(progress);
  var sparkScale = interpolate([0, 0.47, 0.50, 0.62, 1], [0.4, 0.4, 1.15, 1, 0.4])(progress);
  var speedOpacity = interpolate([0, 0.42, 0.46, 0.52, 0.56, 1], [0, 0, 1, 1, 0, 0])(progress);
  var dustOpacity = interpolate([0, 0.80, 0.85, 0.95, 1], [0, 0, 1, 0, 0])(progress);
  var dustScale = interpolate([0, 0.80, 0.85, 1.0, 1], [0.5, 0.5, 1.4, 1.7, 1.7])(progress);
  return {
    shoulderAngle: shoulderAngle, torsoLean: torsoLean, jumpY: jumpY, squashY: squashY, camScale: camScale,
    shakeEnv: slashShakeEnv + landShakeEnv, sparkOpacity: sparkOpacity, sparkScale: sparkScale,
    speedOpacity: speedOpacity, dustOpacity: dustOpacity, dustScale: dustScale,
  };
}

function JumpSlashScene(ctx) {
  var progress = ctx.progress;
  var t = ctx.tweaks;
  var p = JumpSlashPose(progress);
  var shakeAmp = t.cameraShake ? 5 : 0;
  var shakeX = p.shakeEnv * shakeAmp * Math.sin(progress * 340);
  var shakeY = p.jumpY * 0.22 + p.shakeEnv * shakeAmp * 0.6 * Math.cos(progress * 280);
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: '#0b0b0e', overflow: 'hidden' }}>
      <World
        camScale={p.camScale} shakeX={shakeX} shakeY={shakeY}
        shoulderAngle={p.shoulderAngle} torsoLean={p.torsoLean} kneeShift={0}
        armor={t.armorTone} sparkOpacity={p.sparkOpacity} sparkScale={p.sparkScale} speedOpacity={p.speedOpacity}
        jumpY={p.jumpY} squashY={p.squashY} dustOpacity={p.dustOpacity} dustScale={p.dustScale}
        hudVisible={t.hudVisible}
      />
    </div>
  );
}

function KnightAttackApp() {
  var tw = useTweaks(window.TWEAK_DEFAULTS);
  var t = tw[0], setTweak = tw[1];
  var scenes = {
    Ready: function (ctx) { return <ReadyScene {...ctx} tweaks={t} />; },
    Strike: function (ctx) { return <StrikeScene {...ctx} tweaks={t} />; },
    JumpSlash: function (ctx) { return <JumpSlashScene {...ctx} tweaks={t} />; },
  };
  return (
    <div style={{ position: 'relative', width: 1280, height: 720 }}>
      <SceneStage width={1280} height={720} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#0b0b0e">
        {scenes}
      </SceneStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={function (v) { setTweak('motionEditor', v); }} />
        <TweakSection label="Look" />
        <TweakColor label="Armor tone" value={t.armorTone} options={['#6e6280', '#8f7aa8', '#4a4550', '#8a6a3f']} onChange={function (v) { setTweak('armorTone', v); }} />
        <TweakToggle label="HUD" value={t.hudVisible} onChange={function (v) { setTweak('hudVisible', v); }} />
        <TweakToggle label="Camera shake" value={t.cameraShake} onChange={function (v) { setTweak('cameraShake', v); }} />
      </TweaksPanel>
    </div>
  );
}

window.KnightAttackApp = KnightAttackApp;
