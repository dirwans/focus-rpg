import { useState } from 'react'
import { useGameStore } from '../store/gameStore'
import races from '../data/races.json'
import PrologueModal from './PrologueModal'

export default function RaceSelect({ skipPrologue = false }) {
  const selectRace = useGameStore((s) => s.selectRace)
  const [showPrologue, setShowPrologue] = useState(!skipPrologue)

  if (showPrologue) {
    return <PrologueModal onClose={() => setShowPrologue(false)} />
  }

  return (
    <div style={styles.overlay}>
      <style>{`
        @keyframes rs-spin  { to { transform: rotate(360deg); } }
        @keyframes rs-spin-slow { to { transform: rotate(-360deg); } }
        @keyframes rs-glow  {
          0%,100% { filter: brightness(0) invert(1) sepia(1) saturate(4) hue-rotate(330deg) brightness(0.45) drop-shadow(0 0 3px rgba(255,70,0,.55)) drop-shadow(0 0 8px rgba(200,30,0,.3)); }
          50%     { filter: brightness(0) invert(1) sepia(1) saturate(4) hue-rotate(330deg) brightness(0.65) drop-shadow(0 0 6px rgba(255,80,0,.75)) drop-shadow(0 0 16px rgba(200,30,0,.45)); }
        }
        @keyframes rs-glow-blue {
          0%,100% { filter: hue-rotate(300deg) saturate(1.8) brightness(.75) drop-shadow(0 0 3px rgba(0,200,255,.5)) drop-shadow(0 0 8px rgba(0,180,240,.25)); }
          50%     { filter: hue-rotate(300deg) saturate(2.4) brightness(1.0) drop-shadow(0 0 8px rgba(0,225,255,.9)) drop-shadow(0 0 18px rgba(0,210,255,.55)); }
        }
        @keyframes rs-glow-bionex {
          0%,100% { filter: brightness(0) invert(1) sepia(1) saturate(6) hue-rotate(5deg) brightness(.9) drop-shadow(0 0 2px rgba(255,213,74,.35)) drop-shadow(0 0 7px rgba(255,200,60,.18)); }
          50%     { filter: brightness(0) invert(1) sepia(1) saturate(6) hue-rotate(5deg) brightness(1.1) drop-shadow(0 0 5px rgba(255,220,80,.55)) drop-shadow(0 0 13px rgba(255,205,65,.28)) drop-shadow(0 0 28px rgba(255,190,40,.14)); }
        }
        @keyframes rs-ring-bionex {
          0%,100% { opacity:.08; transform:scale(1); }
          50%     { opacity:.28; transform:scale(1.06); }
        }
        @keyframes rs-ring  {
          0%,100% { opacity:.2; transform:scale(1);    }
          50%     { opacity:.5; transform:scale(1.1);  }
        }
        @keyframes rs-ring-blue {
          0%,100% { opacity:.15; transform:scale(1);   }
          50%     { opacity:.5;  transform:scale(1.12); }
        }
      `}</style>

      <div style={{ ...styles.modal, position: 'relative' }}>
        {useGameStore.getState().player.race && (
          <button onClick={() => useGameStore.getState().closeRaceSelect()} style={{position:'absolute', top: 20, left: 16, background:'transparent', border:'none', color:'#00e5ff', fontSize: 20, cursor:'pointer', display:'flex', alignItems:'center'}}>❮</button>
        )}
        <div style={styles.title}>⚔️ CHOOSE YOUR RACE</div>
        <div style={styles.sub}>This cannot be changed later</div>

        {Object.values(races).map((race) => (
          <button key={race.id} style={styles.card} onClick={() => selectRace(race.id)}>

            {/* Visual: Arctron & Celestra get animated logos, Bionex keeps emoji */}
            {race.id === 'arctron' ? (
              <div style={{ position:'relative', width:44, height:44, flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center' }}>
                <div style={{ position:'absolute', width:42, height:42, borderRadius:'50%', border:'1px solid rgba(255,100,0,0.35)', animation:'rs-ring 3s ease-in-out infinite' }} />
                <div style={{ position:'absolute', width:54, height:54, borderRadius:'50%', border:'1px solid rgba(255,100,0,0.2)', animation:'rs-ring 3s ease-in-out 1.5s infinite' }} />
                <img
                  src="/assets/arctron_logo_v2_nobg.png"
                  alt="Arctron"
                  style={{ width:32, height:32, objectFit:'contain', animation:'rs-glow 3.5s ease-in-out infinite' }}
                />
              </div>
            ) : race.id === 'celestra' ? (
              <div style={{ position:'relative', width:44, height:44, flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center' }}>
                <div style={{ position:'absolute', width:44, height:44, borderRadius:'50%', border:'1px solid rgba(0,229,255,0.3)', animation:'rs-ring-blue 4s ease-in-out infinite' }} />
                <div style={{ position:'absolute', width:58, height:58, borderRadius:'50%', border:'1px solid rgba(123,47,255,0.2)', animation:'rs-ring-blue 4s ease-in-out 2s infinite' }} />
                <img
                  src="/assets/celestra_logo_nobg.png"
                  alt="Celestra"
                  style={{ width:34, height:34, objectFit:'contain', animation:'rs-glow-blue 4s ease-in-out infinite' }}
                />
              </div>
            ) : race.id === 'bionex' ? (
              <div style={{ position:'relative', width:44, height:44, flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center' }}>
                <div style={{ position:'absolute', width:44, height:44, borderRadius:'50%', border:'1px solid rgba(160,215,255,0.2)', animation:'rs-ring-bionex 5s ease-in-out infinite' }} />
                <div style={{ position:'absolute', width:56, height:56, borderRadius:'50%', border:'.5px solid rgba(210,190,110,0.12)', animation:'rs-ring-bionex 5s ease-in-out 2.5s infinite' }} />
                <img
                  src="/assets/bionex_logo_nobg.png"
                  alt="Bionex"
                  style={{ width:34, height:34, objectFit:'contain', animation:'rs-glow-bionex 5s ease-in-out infinite' }}
                />
              </div>
            ) : (
              <span style={styles.emoji}>{race.emoji}</span>
            )}

            <div style={styles.info}>
              <div style={styles.raceName}>{race.name.toUpperCase()}</div>
              <div style={styles.raceDesc}>{race.description}</div>
              <div style={styles.specSection}>
                <div style={styles.specTitle}>ADVANTAGES:</div>
                {race.strengths.map((str, i) => (
                  <div key={i} style={styles.specItem('#44ff88')}>{str}</div>
                ))}
                <div style={styles.specTitle}>DISADVANTAGES:</div>
                {race.weaknesses.map((weak, i) => (
                  <div key={i} style={styles.specItem('#ff4444')}>{weak}</div>
                ))}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}

const styles = {
  overlay:   { position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 },
  modal:     { background: '#080d1a', border: '1px solid #1a3a5c', borderRadius: 16, padding: '20px 20px 80px 20px', width: 360, display: 'flex', flexDirection: 'column', gap: 12, maxHeight: '90vh', overflowY: 'auto' },
  title:     { fontFamily: 'var(--font-title)', fontSize: 16, fontWeight: 900, color: '#00e5ff', textAlign: 'center', letterSpacing: 2 },
  sub:       { fontFamily: 'var(--font-mono)', fontSize: 14, color: '#7ec8e3', textAlign: 'center', marginBottom: 4, fontWeight: 800 },
  card:      { background: 'rgba(3, 8, 20, 0.8)', border: '1px solid rgba(0, 229, 255, 0.25)', borderRadius: 12, padding: 14, display: 'flex', gap: 12, alignItems: 'flex-start', cursor: 'pointer', textAlign: 'left', transition: 'border-color 0.2s', width: '100%', boxShadow: '0 4px 12px rgba(0,0,0,0.4)' },
  emoji:     { fontSize: 36 },
  info:      { flex: 1 },
  raceName:  { fontFamily: 'var(--font-title)', fontSize: 14, fontWeight: 800, color: '#e0f4ff', marginBottom: 4 },
  raceDesc:  { fontFamily: 'var(--font-body)', fontSize: 14, color: '#7ec8e3', marginBottom: 6, lineHeight: 1.5, fontWeight: 700 },
  specSection: { marginTop: 4, display: 'flex', flexDirection: 'column', gap: 2 },
  specTitle: { fontFamily: 'var(--font-title)', fontSize: 14, color: '#7ab0d0', letterSpacing: 0.5, marginTop: 4, fontWeight: 800 },
  specItem:  (c) => ({ fontFamily: 'var(--font-body)', fontSize: 14, color: c, lineHeight: 1.3, fontWeight: 700 }),
}
